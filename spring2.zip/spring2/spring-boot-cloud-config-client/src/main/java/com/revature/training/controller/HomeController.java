package com.revature.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.revature.training.model.Company;

@RestController
public class HomeController {
	
	@Autowired
	Company company;
	
	
	@GetMapping("/companyDetails")
	public Company getDetails() {
		return company;
	}

}
