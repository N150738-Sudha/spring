package com;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.revature.pms.config.AppConfig;
import com.revature.pms.model.Email;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        AbstractApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        
        Email employee1 = (Email) context.getBean("email");


        System.out.println(employee1);
        
        context.registerShutdownHook();
        
        
    }
}
