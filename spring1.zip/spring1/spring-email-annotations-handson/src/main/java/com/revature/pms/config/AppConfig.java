package com.revature.pms.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.revature.pms.model.Email;
import com.revature.pms.model.From;
import com.revature.pms.model.To;



@Configuration
public class AppConfig {
	@Bean(name = "email")
	public Email getEmail() {
		return new Email();
	}
	
	@Bean(name = "to")
	public To getTo() {
		return new To("Sankar","sankar@gmail.com");
	}
	
	@Bean(name = "from")
	public From getFrom() {
		return new From("Dhana","dhana@gmail.com");
	}
	
}
