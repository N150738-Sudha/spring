package com.revature.pms.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Scope;

import com.revature.pms.model.ContactDetails;
import com.revature.pms.model.Email;
import com.revature.pms.model.Employee;

@Configuration
//@ComponentScan("com.revature.pms.model","com.revature.pms.service")
@EnableAspectJAutoProxy
@ComponentScan("com")
public class AppConfig {


	


}
