package com.revature.pms.repository;

import org.springframework.stereotype.Repository;

import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

@Repository
@NoArgsConstructor
public class EmployeeRepository {
	public String getEmpFromDB() {
		return "Employee Repository";
	}

}
