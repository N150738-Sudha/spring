package com.revature.pms.aspects;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {
	//@Before("execution(* com.revature.pms.model.Account+.*(..))")
	//@Before(value="execution(com.revature.pms.model.Account.*(..))")
	@Before(" execution(* com.revature.pms.model.Account.withdraw(..))")
	public void logDetails1() {
		System.out.println("#### Logging happened before the method");
	}
	
	@Before(" execution(* com.revature.pms.model.Account.*(..))")
	public void logDetails2() {
		System.out.println("#### Logging happened before GENERAL");
	}
	
	@After("execution(* com.revature.pms.model.*.*(..))")
	public void log2() {
		System.out.println("#### Logging happened before for APPLICATION");
	}

}
