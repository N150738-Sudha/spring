package com.revature.pms.service;

import org.springframework.stereotype.Service;

@Service
public class EmployeeService {
	public String getEmp() {
		return "Employee Service";
	}

}
