package com.revature.pms.aspects;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class TransactionAspect {
	public void dd() {
		System.out.println("############# Transaction started 1");
	}
	
	public void dd2() {
		System.out.println("####### Transaction started 2");
	}
	
	@Pointcut(" execution(* com.revature.pms.service.EmployeeService.*(..))")
	public void transactionStarted1() {}
	
	@Pointcut("within(* com.revature.pms.service.EmployeeService)")
	public void transactionStarted2() {}
	
	@Pointcut("this(* com.revature.pms.service.EmployeeService.*(..))")
	public void transactionStarted3() {}
	
	//interface
	@Pointcut("target(* com.revature.pms.EmpI)")
	public void transactionStarted4() {}
	
	
}
