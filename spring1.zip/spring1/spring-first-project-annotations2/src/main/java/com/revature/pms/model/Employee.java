package com.revature.pms.model;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component("emp1")
@Data
public class Employee {
	private int employeeId;
	private String employeeName;
	private String employeeAddress;
	private int salary;
	
	//dependent object
	@Autowired()
	@Qualifier("email2")
	private Email email;
	
	
	private ContactDetails contactDetails;
	
	//init method
	@PostConstruct
	public void start() {
		System.out.println("Initial method start is called");
		employeeName = "sudha";
	}
	
	//Destroy method
	@PreDestroy
	public void destroyIt() {
		System.out.println("Object is going to destroy");
	}
	
}
