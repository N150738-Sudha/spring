package com.revature.pms.model;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class Account {
	
	private int balance=100000;
	
	public void withdraw(int amount) {
		
			balance = balance-amount;
			System.out.println("INR : "+amount+" debited and your current balance is "+balance);
		
	}
	
	public void deposit(int amount) {

			balance = balance+amount;
			System.out.println("INR : "+amount+" credited and your current balance is "+balance);
	}
	public void changePin(int newPin,int num1,int num2)
	{
		System.out.println(newPin + " changed successfully");
	}
}
