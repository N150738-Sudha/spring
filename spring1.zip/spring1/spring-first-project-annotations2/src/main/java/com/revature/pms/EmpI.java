package com.revature.pms;

public interface EmpI {

}
