package com.revature.pms.model;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Component
@EqualsAndHashCode
@ToString
@Getter
public class ContactDetails {
	
	private String mobileNumber;
	private String alternateMobileNumber;
	private String parentMobileNumber;
	
	@PostConstruct
	public void contactInit() {
		System.out.println("#####CONTACT init called");
	}
	
	
}
