package com;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.revature.pms.config.AppConfig;
import com.revature.pms.model.Account;
import com.revature.pms.model.Email;
import com.revature.pms.model.Employee;
import com.revature.pms.repository.EmployeeRepository;
import com.revature.pms.service.EmployeeService;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        AbstractApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        
        Employee employee1 = (Employee) context.getBean("emp1");
        Email email= (Email) context.getBean("email2");
      
        
        
        
        employee1.setEmployeeId(1);
        employee1.setEmployeeName("Rani");

        System.out.println(employee1);
        
        EmployeeService service = context.getBean(EmployeeService.class);
        EmployeeRepository repository = context.getBean(EmployeeRepository.class);
        
        System.out.println(service.getEmp());
        System.out.println(repository.getEmpFromDB());
        
        //Account
        Account account = context.getBean(Account.class);
        
        account.withdraw(-32000);
        account.deposit(23000);
        account.changePin(324,2,3);
        
        context.registerShutdownHook();
        
        
    }
}
