package com.revature.training.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.revature.training.model.Employee;

@RestController
public class HelloWorldController {
	@RequestMapping("/employee")
	public Employee getMessage() {
		Employee employee = new Employee(1,"Sankar",30000);
		employee.setEmployeeId(3);
		return employee;
	}
	
	@RequestMapping("/home")
	public String home() {
		return "Welcome to revature training";
	}
	
	@RequestMapping("/index")
	public String index() {
		return "Welcome to index page";
	}
	
	@RequestMapping("/employeeDetails")
	public int employeeId() {
		return new Employee().getEmployeeId();
	}
}
