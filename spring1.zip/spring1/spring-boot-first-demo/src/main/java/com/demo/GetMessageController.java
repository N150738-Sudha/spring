package com.demo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GetMessageController {
	@RequestMapping("/message")
	public String getMessage() {
		return "Getting message from controller";
	}

}
