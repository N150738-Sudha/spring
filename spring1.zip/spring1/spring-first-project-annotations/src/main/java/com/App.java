package com;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.revature.pms.config.AppConfig;
import com.revature.pms.model.ContactDetails;
import com.revature.pms.model.Email;
import com.revature.pms.model.Employee;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        AbstractApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        
        Employee employee1 = (Employee) context.getBean("emp1");
        Email email = (Email) context.getBean("email2");
        ContactDetails contactDetails = (ContactDetails) context.getBean("contactDetails");
        
        email.setTo("sankar@gmail.com");
        email.setFrom("rani@gmail.com");
        
        contactDetails.setParentMobileNumber("8374");
        
        employee1.setEmployeeId(1);
        employee1.setEmployeeName("Rani");
        employee1.setEmail(email);
        employee1.setContactDetails(contactDetails);

        System.out.println(employee1);
        
        context.registerShutdownHook();
        
        
    }
}
