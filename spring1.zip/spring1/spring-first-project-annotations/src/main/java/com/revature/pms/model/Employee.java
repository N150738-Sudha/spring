package com.revature.pms.model;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;


public class Employee {
	private int employeeId;
	private String employeeName;
	private String employeeAddress;
	private int salary;
	
	//dependent object
	@Autowired()
	@Qualifier("email2")
	private Email email;
	
	
	private ContactDetails contactDetails;
	
	//init method
	@PostConstruct
	public void start() {
		System.out.println("Initial method start is called");
		employeeName = "sudha";
	}
	
	//Destroy method
	@PreDestroy
	public void destroyIt() {
		System.out.println("Object is going to destroy");
	}
	public Employee() {
		System.out.println("Employee default constructor called");
	}
	public Employee(int employeeId, String employeeName, String employeeAddress, int salary) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeAddress = employeeAddress;
		this.salary = salary;
		System.out.println("Employee parametrized constructor called");
	}
	
	
	
	public Employee(int employeeId, String employeeName, String employeeAddress, int salary, Email email) {
		super();
		System.out.println("Parametrized constructor with 5 fields is called");
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeAddress = employeeAddress;
		this.salary = salary;
		this.email = email;
	}
	
	
	public Employee(int employeeId, String employeeName, String employeeAddress, int salary, Email email,
			ContactDetails contactDetails) {
		super();
		System.out.println("Parametrized constructor with 6 fields is called");
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeAddress = employeeAddress;
		this.salary = salary;
		this.email = email;
		this.contactDetails = contactDetails;
	}
	public Employee(int employeeId, String employeeName) {
		super();
		System.out.println("employee id and name constructor called");
		
		this.employeeId = employeeId;
		this.employeeName = employeeName;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeAddress() {
		return employeeAddress;
	}
	public void setEmployeeAddress(String employeeAddress) {
		this.employeeAddress = employeeAddress;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	
	public Email getEmail() {
		return email;
	}

	public void setEmail(Email email) {
		this.email = email;
	}

	public ContactDetails getContactDetails() {
		return contactDetails;
	}

	public void setContactDetails(ContactDetails contactDetails) {
		this.contactDetails = contactDetails;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeAddress="
				+ employeeAddress + ", salary=" + salary + ", email=" + email + ", contactDetails=" + contactDetails
				+ "]";
	}
	

}
