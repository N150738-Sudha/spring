package com.revature.pms.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.revature.pms.model.ContactDetails;
import com.revature.pms.model.Email;
import com.revature.pms.model.Employee;

@Configuration
public class AppConfig {

	@Bean(name = "emp1")
	//@Scope("prototype")
	public Employee geEmployee() {
		return new Employee();
	}

	@Bean(name = "email1")
	public Email getEmail1() {
		return new Email("abc@gmail.com", "xyz@gmail.com", "Regarding problem solving session",
				"we want another extra session");
	}

	@Bean(name = "email2")
	public Email getEmail2() {
		return new Email("abc1@gmail.com", "xyz1@gmail.com", "Regarding leave",
				"I want leave for 3 days");
	}
	
	@Bean(name = "contactDetails")
	public ContactDetails getContactDetails() {
		return new ContactDetails();
	}

}
