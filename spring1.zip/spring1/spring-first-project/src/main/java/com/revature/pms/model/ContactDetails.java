package com.revature.pms.model;

import org.springframework.beans.factory.annotation.Autowired;

public class ContactDetails {
	private String mobileNumber;
	private String alternateMobileNumber;
	private String parentMobileNumber;
	
	
	
	public ContactDetails() {
		System.out.println("contact details default constructor");
	}

	public ContactDetails(String mobileNumber, String alternateMobileNumber, String parentMobileNumber) {
		super();
		this.mobileNumber = mobileNumber;
		this.alternateMobileNumber = alternateMobileNumber;
		this.parentMobileNumber = parentMobileNumber;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getAlternateMobileNumber() {
		return alternateMobileNumber;
	}

	public void setAlternateMobileNumber(String alternateMobileNumber) {
		this.alternateMobileNumber = alternateMobileNumber;
	}

	public String getParentMobileNumber() {
		return parentMobileNumber;
	}

	public void setParentMobileNumber(String parentMobileNumber) {
		this.parentMobileNumber = parentMobileNumber;
	}

	@Override
	public String toString() {
		return "ContactDetails [mobileNumber=" + mobileNumber + ", alternateMobileNumber=" + alternateMobileNumber
				+ ", parentMobileNumber=" + parentMobileNumber + "]";
	}
	
	
}
