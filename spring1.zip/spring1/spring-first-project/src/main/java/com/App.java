package com;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.revature.pms.model.ContactDetails;
import com.revature.pms.model.Employee;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	
        AbstractApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
        
        Employee employee1 = (Employee) context.getBean("emp1");
        System.out.println(employee1);
        
        Employee employee2 = (Employee) context.getBean("emp2");
        System.out.println(employee2);
        
        context.registerShutdownHook();
        
        
        
    }
}
