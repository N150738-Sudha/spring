package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class SpringBootRevatureDockerDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRevatureDockerDemoApplication.class, args);
	}

	@GetMapping("/revaturetraining")
	public String revatureTraining() {
		return "Welcome to revature training - sudha";
	}
	
	@GetMapping("/mock")
	public String mock() {
		return "Welcome to Mock Interviews";
	}
}
