package com.revature.training.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class GitDemoController {

}
